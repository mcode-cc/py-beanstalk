# -*- coding: utf-8 -*-

#   Copyright 2016 Andrey Aleksandrov
#   Издательский дом "Комсомольская правда"

#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#   http://www.apache.org/licenses/LICENSE-2.0
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.

import json
from bottle import Bottle
from bottle import server_names

__author__ = 'Andrey Aleksandrov'
__version__ = '0.2.1'


class Router(object):

    def __init__(self, nodes=None, subscribe=None, log=None):
        self.nodes = nodes
        self.log = log
        self.subscribe = subscribe
        self.execute = True
        self.app = Bottle()
        self.channel = 'wsgiref@127.0.0.1:8080'

    def add(self, path=None, method=None, callback=None):
        try:
            self.app.route(
                path=path,
                method=method or ['GET', 'POST'],
                callback=callback or self.handler
            )
        except Exception, e:
            self.log.error("%s: %s" % (self.__class__.__name__, str(e)))

    def handler(self, *args, **kwargs):
        pass

    def send(self, message):
        if message['subscribe'] in self.subscribe:
            for channel in self.subscribe[message['subscribe']]:
                tube, node = channel.split('@')
                w = self.nodes[node]
                w.use(tube)
                w.put(json.dumps(message))

    def run(self, channel=None):
        if channel is not None:
            self.channel = channel
        self.log.debug(channel)
        server = self.channel.partition('@')[0]
        host = self.channel.partition('@')[2].partition(':')[0] or '127.0.0.1'
        port = self.channel.partition('@')[2].partition(':')[2] or 8080
        if len(self.app.routes) == 0:
            self.add('<:re:.+>')
        if server in server_names:
            self.app.run(host=host, port=int(port), server=server)
        else:
            self.app.run(host=host, port=int(port))
