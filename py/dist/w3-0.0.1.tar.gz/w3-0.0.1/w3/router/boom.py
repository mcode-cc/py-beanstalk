# -*- coding: utf-8 -*-

#   Copyright 2015 Andrey Aleksandrov and Nikolay Spiridonov
#   Издательский дом "Комсомольская правда"

#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#   http://www.apache.org/licenses/LICENSE-2.0
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.

import json
import signal
__author__ = 'Andrey Aleksandrov'
__version__ = '0.2.1'


class Router(object):

    def __init__(self, nodes=None, subscribe=None, log=None):
        self.nodes = nodes
        self.log = log
        self.subscribe = subscribe
        self.execute = True

    def send(self, message):
        if message['subscribe'] in self.subscribe:
            for channel in self.subscribe[message['subscribe']]:
                tube, node = channel.split('@')
                w = self.nodes[node]
                w.use(tube)
                w.put(json.dumps(message))

    def run(self, channel=None):
        signal.signal(signal.SIGINT, self.signal_handler)
        tube, node = channel.split('@')
        self.log.debug(channel)
        w = self.nodes[node]
        w.watch(tube)
        while self.execute:
            job = None
            try:
                job = w.reserve(timeout=5)
                if job is not None:
                    self.receive(
                        json.loads(str(job.body).encode('utf-8')),
                        channel
                    )
                    job.delete()
            except Exception, e:
                self.log.error(e)
                if job is not None:
                    job.delete()

    def receive(self, message, channel=None):
        if (
            isinstance(message, dict) and
            '@context' in message and
            message['@context'] == 'message'
        ):
            self.send(message)

    def signal_handler(self, signum, frame):
        self.log.debug("exit")
        self.execute = False
